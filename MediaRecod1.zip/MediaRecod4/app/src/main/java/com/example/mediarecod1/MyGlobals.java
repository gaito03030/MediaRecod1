package com.example.mediarecod1;

import android.app.Application;

public class MyGlobals extends Application {

    String name = "";
    String select = "";
    Boolean onsei = true;

}
